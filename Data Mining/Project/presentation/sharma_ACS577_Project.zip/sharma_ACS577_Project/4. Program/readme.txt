jupyter_script contains the main program file which is used to data exploaration, data pre-process, traning, evaluating the model. 

trained_lstm_model.h5 is the trained model.

and the folder 'app' contains the GUI web-app devleoped using streamlit. You can start the web app in localhost by typing 'streamlit run app.py' command in cmd when inside the folder.
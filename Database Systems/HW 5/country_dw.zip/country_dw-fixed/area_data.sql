insert into area
values (1, ' > 301230');
insert into area
values (2, ' 301230  - 37330');
insert into area
values (3, ' 37330 - 412');
insert into area
values (4, ' < 412');
commit;

insert into population
values (1, ' > 10647511');
insert into population
values (2, ' 10647511 - 2826683');
insert into population
values (3, ' 2826683 - 72751');
insert into population
values (4, ' < 72751');
commit;
